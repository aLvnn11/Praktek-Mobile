import 'package:flutter/material.dart';
import 'package:basic/components/ShoppingList.dart';
import 'package:provider/provider.dart';

class ListProductProvider extends ChangeNotifier {
  List<ShoppingList> _shoppingList = [];
  List<ShoppingList> get getShoppingList => _shoppingList;
  set setShoppingList(value) {
    _shoppingList = value;
    notifyListeners();
  }

  void deletedById(ShoppingList) {
    _shoppingList.remove(ShoppingList);
    notifyListeners();
  }
}
