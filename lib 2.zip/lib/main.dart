import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wakelock/wakelock.dart';
import 'package:flutter_spinbox/flutter_spinbox.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String? _image;
  double _score = 0;
  final ImagePicker _picker = ImagePicker();
  final String _keyScore = 'score';
  final String _keyImage = 'image';
  late SharedPreferences prefs;

  @override
  void initState() {
    super.initState();
    // Mengaktifkan wakelock saat halaman dimuat
    Wakelock.enable();
    loadData(); // Memuat data SharedPreferences
  }

  void loadData() async {
    prefs = await SharedPreferences.getInstance();
    setState(() {
      _score = prefs.getDouble(_keyScore) ?? 0;
      _image = prefs.getString(_keyImage);
    });
  }

  @override
  void dispose() {
    super.dispose();
    // Menonaktifkan wakelock saat halaman ditutup
    Wakelock.disable();
  }

  Future<void> _setScore(double value) async {
    prefs.setDouble(_keyScore, value);
    setState(() {
      _score = prefs.getDouble(_keyScore) ?? 0;
    });
  }

  Future<void> _setImage(String? value) async {
    if (value != null) {
      prefs.setString(_keyImage, value);
      setState(() {
        _image = prefs.getString(_keyImage);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Padding(
        padding: EdgeInsets.all(8.0),
        child: Center(
          child: Column(
            children: [
              Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(color: Colors.red[200]),
                child: _image != null
                    ? Image.file(
                        File(_image!),
                        width: 200.0,
                        height: 200.0,
                        fit: BoxFit.fitHeight,
                      )
                    : Container(
                        decoration: BoxDecoration(
                            color: Color.fromARGB(255, 198, 198, 198)),
                        width: 200,
                        height: 200,
                        child: Icon(
                          Icons.camera_alt,
                          color: Colors.grey[800],
                        ),
                      ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  onPressed: () async {
                    XFile? image = await _picker.pickImage(
                      source: ImageSource.gallery,
                    );
                    _setImage(image?.path);
                  },
                  child: Text("Take Image"),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SpinBox(
                  max: 10.0,
                  min: 0.0,
                  value: _score,
                  decimals: 1,
                  step: 0.1,
                  decoration: InputDecoration(labelText: 'Decimal'),
                  onChanged: _setScore,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
